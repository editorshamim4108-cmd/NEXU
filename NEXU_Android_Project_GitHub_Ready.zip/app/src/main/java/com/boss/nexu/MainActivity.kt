package com.boss.nexu

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.SettingsVoice
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.sin

val DeepBlack = Color(0xFF050508)
val PanelDark = Color(0xFF0D0E17)
val NeonPurple = Color(0xFFB026FF)
val ElectricBlue = Color(0xFF0066FF)
val CyberCyan = Color(0xFF00F0FF)
val StatusGreen = Color(0xFF00FF9D)

class MainActivity : ComponentActivity() {

    private lateinit var voiceEngine: NexuVoiceEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voiceEngine = NexuVoiceEngine(this)

        setContent {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = DeepBlack
            ) {
                NexuCommandDeckScreen(voiceEngine = voiceEngine)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // ব্যবহারকারী Settings থেকে Accessibility Permission দিয়ে ফিরে এলে নিজে থেকে কাজ Resume করবে
        voiceEngine.checkAndResumeAfterPermission()
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceEngine.shutdown()
    }
}

@Composable
fun NexuCommandDeckScreen(voiceEngine: NexuVoiceEngine) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isSessionActive by voiceEngine.isSessionActive.collectAsState()
    val status by voiceEngine.status.collectAsState()
    val lastHeard by voiceEngine.lastHeardText.collectAsState()
    val nexuReply by voiceEngine.nexuReplyText.collectAsState()
    val logs by voiceEngine.activityLogs.collectAsState()
    val speechRate by voiceEngine.speechRate.collectAsState()
    val languageLocale by voiceEngine.languageLocale.collectAsState()
    val usageMinutes by voiceEngine.activeUsageMinutes.collectAsState()
    val showRestAlert by voiceEngine.showRestAlert.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            voiceEngine.startPersistentSession()
        } else {
            voiceEngine.speak("বস, আপনার কথা শোনার জন্য মাইক্রোফোন পারমিশন প্রয়োজন।")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DeepBlack, Color(0xFF090614), DeepBlack)
                )
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        FloatingHeaderBar(
            status = status,
            languageLocale = languageLocale,
            usageMinutes = usageMinutes,
            onToggleLanguage = { voiceEngine.toggleLanguage() }
        )

        if (showRestAlert) {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B123A)),
                border = BorderStroke(1.dp, CyberCyan)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "বস, আপনার এখন একটু বিশ্রামের সময় (২ ঘণ্টা পূর্ণ হয়েছে)।",
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { voiceEngine.dismissRestAlert() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                    ) {
                        Text("Reset", color = DeepBlack, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        ThreePhoneMockupDeck(
            status = status,
            isSessionActive = isSessionActive,
            lastHeard = lastHeard,
            logs = logs,
            onOrbClick = {
                if (!hasMicPermission) {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                } else if (isSessionActive) {
                    voiceEngine.stopPersistentSession()
                } else {
                    voiceEngine.startPersistentSession()
                }
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Voice Command Simulator Chips for one-tap testing
        QuickCommandRow(onSimulate = { voiceEngine.simulateCommandFromUi(it) })

        Spacer(modifier = Modifier.height(8.dp))

        AnimatedSoundWaveBar(isActive = isSessionActive && status != AssistantStatus.OFFLINE)

        Spacer(modifier = Modifier.height(8.dp))

        BottomLiveTaskPanel(
            nexuReply = nexuReply,
            speechRate = speechRate,
            onRateChange = { voiceEngine.updateVoiceSettings(it, 1.0f) },
            logs = logs
        )
    }
}

@Composable
fun QuickCommandRow(onSimulate: (String) -> Unit) {
    val commands = listOf(
        "Hey Boss",
        "WhatsApp ওপেন করো",
        "এই লেখাটা পড়ে শোনাও",
        "স্ক্রল করো",
        "Gemini ওপেন করো",
        "ফোনটা লক করে দাও",
        "NEXU অফ হয়ে যাও"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        commands.forEach { cmd ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(PanelDark)
                    .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .clickable { onSimulate(cmd) }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(text = cmd, color = CyberCyan, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun FloatingHeaderBar(
    status: AssistantStatus,
    languageLocale: String,
    usageMinutes: Int,
    onToggleLanguage: () -> Unit
) {
    val badgeColor = when (status) {
        AssistantStatus.LISTENING -> CyberCyan
        AssistantStatus.SPEAKING -> NeonPurple
        AssistantStatus.OFFLINE -> Color.Gray
        else -> StatusGreen
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PanelDark),
        border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(NeonPurple, CyberCyan)))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(badgeColor)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "NEXU // HEY BOSS AI",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = status.label,
                        color = badgeColor,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Rest: ${usageMinutes}/120m",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, CyberCyan.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                        .clickable { onToggleLanguage() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (languageLocale == "bn-BD") "বাংলা" else "EN",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun ThreePhoneMockupDeck(
    status: AssistantStatus,
    isSessionActive: Boolean,
    lastHeard: String,
    logs: List<ActivityLogItem>,
    onOrbClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(265.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SidePhoneMockupCard(
            title = "LIVE TASK",
            accentColor = ElectricBlue,
            modifier = Modifier
                .weight(0.85f)
                .fillMaxHeight(0.88f)
        ) {
            Text(
                text = "WAKE WORD:
"Hey Boss"",
                color = CyberCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "MODE:
${if (isSessionActive) "PERSISTENT" else "STANDBY"}",
                color = if (isSessionActive) StatusGreen else Color.Gray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "BOSS SAID:
$lastHeard",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 10.sp,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
            )
        }

        Card(
            modifier = Modifier
                .weight(1.35f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0814)),
            border = BorderStroke(
                width = 1.8.dp,
                brush = Brush.verticalGradient(listOf(CyberCyan, NeonPurple, ElectricBlue))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "NEXU CORE // BOSS",
                    color = CyberCyan,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )

                GlowingAiOrb(
                    isActive = isSessionActive,
                    onClick = onOrbClick
                )

                Text(
                    text = if (isSessionActive) "Active (ট্যাপ করলে অফ)" else "চালু করতে Orb-এ ট্যাপ করুন",
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        SidePhoneMockupCard(
            title = "SECURITY",
            accentColor = NeonPurple,
            modifier = Modifier
                .weight(0.85f)
                .fillMaxHeight(0.88f)
        ) {
            Text(
                text = "VOICE ID:
BOSS LOCAL",
                color = NeonPurple,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "VISUAL UI:
${if (NexuVisualAccessibilityService.isServiceConnected()) "CONNECTED" else "READY"}",
                color = StatusGreen,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "LAST ACTION:
${logs.firstOrNull()?.title ?: "Ready"}",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 10.sp,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SidePhoneMockupCard(
    title: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PanelDark.copy(alpha = 0.88f)),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            Text(
                text = title,
                color = accentColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            content()
        }
    }
}

@Composable
fun GlowingAiOrb(
    isActive: Boolean,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = if (isActive) 1.15f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(135.dp)
            .clickable { onClick() }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .scale(pulseScale)
        ) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonPurple.copy(alpha = 0.55f),
                        ElectricBlue.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius
                ),
                radius = maxRadius
            )

            drawCircle(
                color = if (isActive) CyberCyan else NeonPurple.copy(alpha = 0.6f),
                radius = maxRadius * 0.68f,
                style = Stroke(width = 3.dp.toPx())
            )

            drawCircle(
                brush = Brush.linearGradient(
                    colors = if (isActive) {
                        listOf(CyberCyan, ElectricBlue, NeonPurple)
                    } else {
                        listOf(Color(0xFF2A1B4E), Color(0xFF11162B))
                    }
                ),
                radius = maxRadius * 0.52f
            )
        }

        Icon(
            imageVector = if (isActive) Icons.Default.Mic else Icons.Default.MicOff,
            contentDescription = "Voice Button",
            tint = Color.White,
            modifier = Modifier.size(30.dp)
        )
    }
}

@Composable
fun AnimatedSoundWaveBar(isActive: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PanelDark),
        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.4f))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            val barCount = 28
            val spacing = size.width / barCount
            val centerY = size.height / 2f

            for (i in 0 until barCount) {
                val angle = phase + (i * 0.35f)
                val normalized = if (isActive) (sin(angle) * 0.5f + 0.5f) else 0.15f
                val barHeight = (size.height * 0.85f * normalized).coerceAtLeast(5f)
                val x = i * spacing + spacing / 2f

                drawLine(
                    brush = Brush.verticalGradient(listOf(CyberCyan, NeonPurple)),
                    start = Offset(x, centerY - barHeight / 2f),
                    end = Offset(x, centerY + barHeight / 2f),
                    strokeWidth = 4.dp.toPx()
                )
            }
        }
    }
}

@Composable
fun BottomLiveTaskPanel(
    nexuReply: String,
    speechRate: Float,
    onRateChange: (Float) -> Unit,
    logs: List<ActivityLogItem>
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PanelDark),
        border = BorderStroke(1.dp, NeonPurple.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "NEXU LIVE VOICE:",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = nexuReply,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.SettingsVoice,
                    contentDescription = null,
                    tint = NeonPurple,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Speed: ${"%.2f".format(speechRate)}x",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    modifier = Modifier.width(90.dp)
                )
                Slider(
                    value = speechRate,
                    onValueChange = onRateChange,
                    valueRange = 0.7f..1.4f,
                    colors = SliderDefaults.colors(
                        thumbColor = CyberCyan,
                        activeTrackColor = NeonPurple
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items(logs) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF141624))
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "[${item.timestamp}] ${item.title}: ${item.detail}",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
