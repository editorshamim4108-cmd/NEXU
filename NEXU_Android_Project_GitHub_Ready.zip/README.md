# PROJECT NEXU — PERSONAL HANDS-FREE ANDROID AI ASSISTANT (হেই বস!)

**NEXU** হলো আপনার ব্যক্তিগত হ্যান্ডস-ফ্রি Android AI Voice Assistant, যা বিশেষভাবে ভিডিও এডিটর এবং ব্যস্ত ব্যবহারকারীদের জন্য তৈরি করা হয়েছে। একবার **"Hey Boss"** বলে ডাকলে এটি সক্রিয় হয় এবং আপনি নিজে অফ করতে না বলা পর্যন্ত (**Persistent Session Mode**) আপনার সব নির্দেশ পালন করে।

## কীভাবে GitHub থেকে সরাসরি আপনার ফোনের জন্য `.apk` ফাইল পাবেন? (কোনো কম্পিউটার বা Android Studio লাগবে না!)

১. আপনার [GitHub](https://github.com)-এ একটি নতুন Repository খুলুন (যেমন: `NEXU-Assistant`)।
২. ডাউনলোড করা জিপ (`NEXU_Android_Project_GitHub_Ready.zip`) ফাইলটি আনজিপ (Unzip/Extract) করে সব ফাইল ও ফোল্ডার আপনার GitHub Repository-তে **Upload files** দিয়ে আপলোড করে **Commit changes** চাপুন।
৩. এবার আপনার GitHub Repository-র ওপরে **Actions** ট্যাবে ক্লিক করুন।
৪. দেখবেন **Build NEXU Android APK** নামের একটি অটোমেটিক বিল্ড চলছে। ২-৩ মিনিট অপেক্ষা করলে সবুজ টিক (`✔`) চিহ্ন আসবে।
৫. ওই বিল্ডের ওপর ক্লিক করে নিচে স্ক্রল করলেই **Artifacts** সেকশনে **`NEXU-Personal-Assistant-APK`** দেখতে পাবেন। সেটিতে ক্লিক করলেই আপনার ফোনে ইন্সটল করার জন্য রেডিমেড **`app-debug.apk`** ডাউনলোড হয়ে যাবে!

## অন্তর্ভুক্ত ১৪টি মডিউল ও ফিচারসমূহ
- **১. Personal Identity:** সব সময় আপনাকে **"বস"** বলে সম্বোধন করে।
- **২. Hey Boss Wake Word & Foreground Service:** ব্যাকগ্রাউন্ডে এবং স্ক্রিন অফ অবস্থাতেও [Android Foreground Service](https://developer.android.com/develop/background-work/services/fgs/service-types) দিয়ে কাজ করে।
- **৩. Persistent Assistant Mode:** একবার চালু করলে নিজে থেকে বন্ধ হয় না; একের পর এক কমান্ড নেয় এবং পারমিশন বা আনলকের পর আগের অসমাপ্ত কাজ (`PendingTaskContext`) নিজে থেকেই Resume করে।
- **৪. Local Voice Profile & Verification:** আপনার কণ্ঠের লোকাল ভয়েস প্রোফাইল সংরক্ষণ ও যাচাই।
- **৫. Natural Bangla, English & Banglish Conversation:** বাংলা ও ইংরেজি ভয়েস স্পিড এবং পিচ কন্ট্রোল ([Android TextToSpeech](https://developer.android.com/reference/android/speech/tts/TextToSpeech))।
- **৬–১২. Live Visual Phone Control & Universal App Control:** [Android AccessibilityService](https://developer.android.com/reference/android/accessibilityservice/AccessibilityService) ব্যবহার করে আপনার চোখের সামনে WhatsApp, YouTube, Gemini, Chrome, Settings ওপেন করা, বাটন ক্লিক, অটো-স্ক্রল, মেসেজ প্রিভিউ এবং ভয়েস ফোন লক (`DevicePolicyManager`)।
- **১৩. Two-Hour Rest System:** টানা ২ ঘণ্টা কাজের পর আপনাকে বিশ্রামের জন্য স্মার্ট রিমাইন্ডার দেয়।
- **১৪. Futuristic Three-Phone Mockup UI:** কালো ব্যাকগ্রাউন্ড, নিওন পার্পল, ইলেকট্রিক ব্লু, সায়ান গ্লোয়িং AI Orb এবং অ্যানিমেটেড সাউন্ড ওয়েভ ([Jetpack Compose](https://developer.android.com/compose))।
